namespace Clients.Api;

public interface IClientsApiAssemblyMarker
{
    
}