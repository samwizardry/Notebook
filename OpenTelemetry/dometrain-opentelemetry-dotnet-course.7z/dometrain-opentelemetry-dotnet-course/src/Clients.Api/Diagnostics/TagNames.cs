namespace Clients.Api.Diagnostics;

internal static class TagNames
{
    public const string ClientId = "client.id";
    public const string ClientMembership = "client.membership";
}