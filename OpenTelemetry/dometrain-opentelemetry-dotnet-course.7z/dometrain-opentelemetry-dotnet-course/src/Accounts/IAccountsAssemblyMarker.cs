namespace Accounts;

public interface IAccountsAssemblyMarker
{
}