namespace Clients.Api.Tests;

[CollectionDefinition("API collection")]
public class ApiTestCollection : ICollectionFixture<ClientsApiFactory>
{

}